import 'package:flutter/material.dart';

var owncolor = Colors.orange;
var seccolor = Colors.deepOrange;
var thirdcolor = Color(0xFFFFB74D);